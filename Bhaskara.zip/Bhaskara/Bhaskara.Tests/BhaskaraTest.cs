namespace Bhaskara.Tests
{
    public class BhaskaraTest
    {
        [Fact]
        public void Duas()
        {
            double N1 = 1, N2 = -3, N3 = 2;

            var resultado = Bhaskara.Bhaskarer.Raizes(N1, N2, N3);

            Assert.Equal(2, resultado.Item1);
            Assert.Equal(1, resultado.Item2);
        }

        [Fact]
        public void Nenhuma()
        {
            double N1 = 1, N2 = 2, N3 = 5;

            var resultado = Bhaskara.Bhaskarer.Raizes(N1, N2, N3);

            Assert.Null(resultado.Item1);
            Assert.Null(resultado.Item2);
        }
    }
}