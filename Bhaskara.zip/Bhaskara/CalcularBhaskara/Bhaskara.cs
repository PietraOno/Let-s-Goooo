﻿namespace Bhaskara
{
    public static class Bhaskarer
    {
        public static (double?, double?) Raizes(double N1, double N2, double N3)
        {
            double delta = (N2 * N2) - (4 * N1 * N3);

            if (delta < 0)
            {
                return (null, null);
            }

            double raizDelta = Math.Sqrt(delta);
            double x1 = (-N2 + raizDelta) / (2 * N1);
            double x2 = (-N2 - raizDelta) / (2 * N1);

            return (x1, x2);
        }
    }
}
