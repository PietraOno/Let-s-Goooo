using Votar;
using Xunit;

namespace VotarTest
{
    public class VotarTest
    {
        public class VotoTests
        {
            [Fact]
            public void TestVotar_Idade11_NaoPodeVotar()
            {
                int idade = 11;
                string esperado = "N�o pode votar, boc�!";

                string obtido = Voto.Votar(idade);

                Assert.Equal(esperado, obtido);
            }

            [Fact]
            public void TestVotar_Idade16_VotoOpcional()
            {
                int idade = 16;
                string esperado = "Voto opcional, toma!";

                string obtido = Voto.Votar(idade);

                Assert.Equal(esperado, obtido);
            }

            [Fact]
            public void TestVotar_Idade18_VotoObrigatorio()
            {
                int idade = 18;
                string esperado = "Voto obrigat�rio, vapo!";

                string obtido = Voto.Votar(idade);

                Assert.Equal(esperado, obtido);
            }

            [Fact]
            public void TestVotar_Idade70_VotoObrigatorio()
            {
                int idade = 70;
                string esperado = "Voto obrigat�rio, vapo!";

                string obtido = Voto.Votar(idade);

                Assert.Equal(esperado, obtido);
            }

            [Fact]
            public void TestVotar_Idade85_VotoOpcional()
            {
                int idade = 85;
                string esperado = "Voto opcional, tomatoma!";

                string obtido = Voto.Votar(idade);

                Assert.Equal(esperado, obtido);
            }
        }
    }
}