﻿namespace Votar
{
    public static class Voto
    {
        public static string Votar(int idade)
        {
            if (idade <= 15)
                return "Não pode votar, bocó!";

            if (idade == 16 || idade == 17)
                return "Voto opcional, toma!";

            if (idade >= 18 && idade <= 70)
                return "Voto obrigatório, vapo!";

            if (idade > 70)
                return "Voto opcional, tomatoma!";

            return "Idade Inválida";
        }
    }
}
